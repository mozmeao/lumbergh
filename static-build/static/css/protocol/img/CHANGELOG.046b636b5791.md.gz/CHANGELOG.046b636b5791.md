# 1.0.1

#Features

* **icons** Added header navigation icons

# 1.0.0

## Features

* **icons** Added new menu, close and expand icons (black & white variants).
* **icons** Removed old close icon.
* **icons** Removed old kebab menu icon.

# 0.0.5

## Features

* **logos** Added Pocket logo
* **icons** Added menu panel arrow icon
* **backgrounds** Added hero curve SVG mask

# 0.0.4

## Features

* **logos** Added firefox logos (release, beta, dev edition, nightly, focus) (#2)

# 0.0.3
* **icons** Remove png support for icons

# 0.0.2

## Features

* **logos** Added mozilla logo
* **icons/ui** Added UI icons (audio, video, close, kebab)
* **icons/social** Added mozilla and protocol icons

# 0.0.1

## Features

* **icons** Added support for social icons (facebook, firefox, github, instagram, pocket, twitter, and youtube)
