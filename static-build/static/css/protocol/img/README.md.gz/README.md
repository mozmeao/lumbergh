# Protocol Assets

This repository contains a set of reusable assets for Mozilla's websites. These assets are available as both svg and png files. Assets include logos and icons.
