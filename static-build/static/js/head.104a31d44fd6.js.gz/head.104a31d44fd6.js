(function() {
    'use strict';
    var docElement = document.documentElement;
    docElement.className = docElement.className.replace(/\bjs-disabled\b/,'') + ' js-enabled';
})();
